
"use client";
import Header from "@/components/header";
import ModalAddProduct from "@/components/modal-component";
import ProductComponent from "@/components/product-component";
import { callAPI } from "@/utils/api-caller";
import Image from "next/image";
import { useEffect, useState } from "react";
export default function Home() {
 
 
  return (
    <div className="relative w-[100vw] h-[100vh]" >
      <Header />
     
    </div>
  );
}
