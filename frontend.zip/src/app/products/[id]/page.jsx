"use client"
import { callAPI } from "@/utils/api-caller";
import { useParams } from "next/navigation";
import { useEffect, useState } from "react";
import ReactMarkdown from 'react-markdown'
import remarkGfm from 'remark-gfm'
const URL_SERVER = process.env.NEXT_PUBLIC_BACKEND_SERVER_MEDIA
const ViewDetailProduct = ()=>{
    const params = useParams()
    const [product, setProduct] = useState(null)
    useEffect(()=>{
        getDetailProduct()
    },[])
    const getDetailProduct = async()=>{
        try {
            const res = await callAPI("/products/" + params.id + "?populate=*", "GET")
            console.log(res)
            setProduct(res.data.data)
        } catch (error) {
            console.log(error)
        }
        
    }
    // id={value.id}
    // key={index} productName={value.attributes.name}
    // price={value.attributes.price}
    // brand={value.attributes.category.data.attributes.name}
    // imageUrl={value.attributes.image.data[0].attributes.url} />
    return (
        product !== null?
            <div className="w-72 bg-white ">
            <a href="#">
            <img src={URL_SERVER + product.attributes.image.data[0].attributes.url}
                alt="Product" className="h-80 w-72 object-cover rounded-t-xl" />
            <div className="px-4 py-3 w-72">
                <span className="text-gray-400 mr-3 uppercase text-xs">{product.attributes.category.data.attributes.name}</span>
                <p className="text-lg font-bold text-black truncate block capitalize">{product.attributes.name}</p>
                <div className="flex items-center">
                <p className="text-lg font-semibold text-black cursor-auto my-3">${product.attributes.price}</p>
              
                <div>
                    
                </div>
                </div>
            </div>
            </a>
            <ReactMarkdown remarkPlugins={[remarkGfm]}>{'# ' + product.attributes.description} </ReactMarkdown>
                    
        </div>
        :
            <div>Sản phẩm không tìm thấy</div>
    )
}
export default ViewDetailProduct;